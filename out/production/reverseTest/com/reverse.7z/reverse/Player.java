package com.reverse;

import iut.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.reflect.Array;
import java.net.URL;

public class Player extends BoxGameItem implements KeyListener{

    private int weight = 80;
    private GameItem objColl = null;
    private double fallSpeed = 3.2;
    private double jumpValue = 100;
    private double angle = 90;
    private Point playerPos = new Point(0, this.getGame().getHeight());
    private boolean isJumping = false;
    private int maxHeight = 583;




    private AnimationHandler animMove = new AnimationHandler(this, 4, 2, "gauche");
    private AnimationHandler idle = new AnimationHandler(this, 4, 10, "idle");

    //[40 : false, 37 : false, 38 : false, 39 : false]

    private Boolean[] keys = new Boolean[]{false, false, false, false};


    public Player(Game g) {
        super(g, "player", 100, 400);
//        this.playerPos.setLocation(100, this.getGame().getHeight());
        this.animMove.initAnim();
    }

    public void gravity(){
        this.moveDA(fallSpeed, -90);
    }


    public void jump()
    {
        if (isJumping && this.getBottom() >= this.getGame().getHeight() - 1) {
            this.changeSprite("saut0");
            this.moveDA(jumpValue, this.angle);
        }

        if(this.getBottom() < this.maxHeight + jumpValue) {
            isJumping = false;
            this.changeSprite("saut1");
        }

        if ( this.getBottom() >= this.getGame().getHeight()- 10) {
            isJumping = false;

        }
    }


    @Override
    public boolean isCollide(GameItem o) {
        if (o != this){
            this.objColl = o;

        }
        return true;
    }


    @Override
    public void collideEffect(GameItem gameItem) {

    }

    @Override
    public String getItemType() {
        return "player";
    }

    @Override
    public void evolve(long l) {
        if (!isJumping && this.getBottom() < this.getGame().getHeight() - 1) {
            this.gravity();
        }

        jump();
        updateMove();
        idle.run("");
     }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        keys[e.getKeyCode()%4] = true;

    }

    @Override
    public void keyReleased(KeyEvent e) {
        keys[e.getKeyCode()%4] = false;
    }

    public void updateMove() {

        if(keys[KeyEvent.VK_LEFT%4]){
            if (this.getLeft() > 0) {
                this.moveXY(-5, 0);
                this.playerPos.x -= 5;
//                this.moveName = "gauche";
                this.animMove.run("gauche");

            }
        }

        if(keys[KeyEvent.VK_RIGHT%4]){
            if (this.getRight() < 800) {
                this.moveXY(+5, 0);
                this.playerPos.x -= 5;
//                this.moveName = "droite";
                this.animMove.run("droite");
                System.out.println(this.getRight() + "   " + this.getGame().getWidth());
            }

        }

        if (!keys[KeyEvent.VK_LEFT%4] && !keys[KeyEvent.VK_RIGHT%4]) {
//            this.moveName = "idle";
//            this.animCount = (this.animCount > 4) ? (this.animCount % 4) : (this.animCount += 1);
            this.idle.run("");
        }

        if(keys[KeyEvent.VK_UP%4]){
            this.isJumping = true;
            if (!isJumping && this.getBottom() >= this.getGame().getHeight() - 1) {
                if (keys[KeyEvent.VK_RIGHT%4]) {
                    this.angle = 45;
                    this.maxHeight = 591;
                } else if (keys[KeyEvent.VK_LEFT%4]) {
                    this.angle = 135;
                    this.maxHeight = 591;
                } else {
                    this.angle = 90;
                    this.maxHeight = 585;
                }

            }

        }

    }
}
